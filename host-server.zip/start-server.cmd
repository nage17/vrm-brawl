@echo off
cd /d "%~dp0"
echo VRM BRAWL - private match server
echo Share the session key only with your friends.
echo Stop this server with Ctrl+C when finished.
node server.mjs
pause
