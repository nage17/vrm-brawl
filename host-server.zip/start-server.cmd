@echo off
cd /d "%~dp0"
echo VRM BRAWL - online match host
echo This starts both the match server and its secure public tunnel.
echo Share the generated URL and session key with your friends only.
echo Keep this window open while playing. Stop with Ctrl+C.
node host.mjs
pause
