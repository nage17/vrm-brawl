import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
function findCloudflared(){
 const candidates=[
  ...(process.env.ProgramFiles? [path.join(process.env.ProgramFiles,'cloudflared','cloudflared.exe')]:[]),
  ...(process.env['ProgramFiles(x86)']? [path.join(process.env['ProgramFiles(x86)'],'cloudflared','cloudflared.exe')]:[]),
  ...(process.env.LOCALAPPDATA? [path.join(process.env.LOCALAPPDATA,'cloudflared','cloudflared.exe')]:[]),
  ...((process.env.PATH??'').split(path.delimiter).map(dir=>path.join(dir,process.platform==='win32'?'cloudflared.exe':'cloudflared'))),
 ];
 return candidates.find(existsSync)??(process.platform==='win32'?'cloudflared.exe':'cloudflared');
}

try{
 const response=await fetch('http://127.0.0.1:8787/health',{signal:AbortSignal.timeout(500)});
 if(response.ok){console.error('8787番ポートですでにサーバーが動いています。既存のサーバーを終了してから再実行してください。');process.exit(1);}
}catch{}

const server=spawn(process.execPath,[path.join(root,'server.mjs')],{cwd:root,stdio:['inherit','pipe','pipe']});
let stopping=false,tunnel=null,publicUrl='';
function stop(code=0){
 if(stopping)return;stopping=true;
 console.log('\nサーバーとトンネルを停止しています…');
 server.kill('SIGTERM');tunnel?.kill('SIGTERM');
 const timer=setTimeout(()=>process.exit(code),2500);timer.unref();
}
process.once('SIGINT',()=>stop(0));process.once('SIGTERM',()=>stop(0));
server.stdout.on('data',data=>process.stdout.write(data));
server.stderr.on('data',data=>process.stderr.write(data));
server.on('error',error=>{console.error('対戦サーバーを起動できません:',error.message);stop(1);});
server.on('exit',(code,signal)=>{if(!stopping){console.error(`対戦サーバーが終了しました (${signal??code})`);stop(code??1);}});

console.log('対戦サーバーを準備しています…');
let ready=false;
for(let i=0;i<40&&!stopping;i++){
 try{const response=await fetch('http://127.0.0.1:8787/health',{signal:AbortSignal.timeout(700)});if(response.ok){ready=true;break;}}catch{}
 await new Promise(resolve=>setTimeout(resolve,250));
}
if(!ready){console.error('対戦サーバーの起動を確認できません。8787番ポートが他のアプリに使われていないか確認してください。');stop(1);}
else if(!stopping){
 const executable=findCloudflared();
 console.log('\n公開用トンネルを開始します。接続URLの発行まで少しお待ちください。\n');
 tunnel=spawn(executable,['tunnel','--url','http://127.0.0.1:8787'],{cwd:root,stdio:['ignore','pipe','pipe']});
 const relay=(data)=>{
  const text=data.toString();process.stdout.write(text);
  if(!publicUrl){const match=text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);if(match){publicUrl=match[0];console.log('\n--- 参加者へ共有する情報 ---\nゲームURL: https://nage17.github.io/vrm-brawl/\nサーバーURL: '+publicUrl+'\n参加キー: 上に表示された「今回の参加キー」\n--- この画面を開いたままにしてください（終了は Ctrl+C）---\n');}}
 };
 tunnel.stdout.on('data',relay);tunnel.stderr.on('data',relay);
 tunnel.on('error',error=>{console.error('cloudflaredを起動できません:',error.message,'\ncloudflaredをインストールしてから再実行してください。');stop(1);});
 tunnel.on('exit',(code,signal)=>{if(!stopping){console.error(`公開用トンネルが終了しました (${signal??code})`);stop(code??1);}});
}
